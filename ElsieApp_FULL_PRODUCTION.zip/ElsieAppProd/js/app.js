function enterParentMode(){alert('Parent Mode');}
function enterElsieMode(){alert('Elsie Mode');}